using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    public Text skor;
    int score = 0;
    public Text menang;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        menang.text ="";
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        rb.AddForce(movement * speed);
    }

    void OnTriggerEnter(collider obj)
    {
        if(obj.gameObject.tag == "target")
        {
            Destroy(obj.gameObject);
            score += 20;
            skor.text = "Score : " + score.ToString();
            GameObject.Find ("target sound").GetComponent<AudioSource>().Play();
        }
        if (score >= 00)
        {
            menang.text = "You Win";
            GameObject.Find ("win sound").GetComponent<AudioSource>().Play();
        }
    }
}